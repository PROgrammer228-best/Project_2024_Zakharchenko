<?php
require_once 'config/database.php';
startSession();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = 'Пожалуйста, заполните все поля';
    } elseif ($password !== $confirm_password) {
        $error = 'Пароли не совпадают';
    } elseif (strlen($password) < 6) {
        $error = 'Пароль должен содержать не менее 6 символов';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Некорректный email адрес';
    } else {
        try {
            // Проверяем, не существует ли уже такой email или username
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
            $stmt->execute([$email, $username]);

            if ($stmt->fetch()) {
                $error = 'Пользователь с таким email или именем уже существует';
            } else {
                // Создаем нового пользователя
                $hashedPassword = hashPassword($password);
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'client')");
                $stmt->execute([$username, $email, $hashedPassword]);

                $success = 'Регистрация прошла успешно! Теперь вы можете войти в систему.';
            }
        } catch (PDOException $e) {
            $error = 'Ошибка базы данных: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - Фотостудия "Кадр"</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header__content">
                <div class="logo">
                    <h1><a href="index.php">Кадр</a></h1>
                    <span>фотостудия</span>
                </div>
                <nav class="nav">
                    <ul class="nav__list">
                        <li><a href="index.php" class="nav__link">Главная</a></li>
                        <li><a href="search.php" class="nav__link">Услуги</a></li>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <a href="login.php" class="btn btn--outline btn--sm">Войти</a>
                </div>
            </div>
        </div>
    </header>

    <main class="main">
        <section class="auth-section">
            <div class="container">
                <div class="auth-form-container">
                    <h1 class="auth-form__title">Регистрация</h1>

                    <?php if ($error): ?>
                        <div class="alert alert--error"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert--success">
                            <?php echo htmlspecialchars($success); ?>
                            <a href="login.php">Войти сейчас</a>
                        </div>
                    <?php endif; ?>

                    <form method="POST" class="auth-form">
                        <div class="form-group">
                            <label for="username" class="form-label">Имя пользователя</label>
                            <input type="text" id="username" name="username" class="form-input" 
                                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" id="email" name="email" class="form-input" 
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="password" class="form-label">Пароль</label>
                            <input type="password" id="password" name="password" class="form-input" 
                                   minlength="6" required>
                            <small class="form-text">Минимум 6 символов</small>
                        </div>

                        <div class="form-group">
                            <label for="confirm_password" class="form-label">Подтвердите пароль</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-input" required>
                        </div>

                        <button type="submit" class="btn btn--primary btn--full">Зарегистрироваться</button>
                    </form>

                    <div class="auth-links">
                        <p>Уже есть аккаунт? <a href="login.php">Войдите</a></p>
                    </div>
                </div>
            </div>
        </section>
    </main>
</body>
</html>