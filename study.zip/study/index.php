<?php
require_once 'config/database.php';
startSession();

// Получаем услуги для отображения
$stmt = $pdo->query("SELECT * FROM services ORDER BY name");
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Фотостудия "Кадр" - Профессиональная фотосъемка</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header__content">
                <div class="logo">
                    <h1><a href="index.php">Кадр</a></h1>
                    <span>фотостудия</span>
                </div>
                <nav class="nav">
                    <ul class="nav__list">
                        <li><a href="index.php" class="nav__link">Главная</a></li>
                        <li><a href="search.php" class="nav__link">Услуги</a></li>
                        <?php if (isLoggedIn()): ?>
                            <li><a href="book_session.php" class="nav__link">Записаться</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <?php if (isLoggedIn()): ?>
                        <span class="user-name">Привет, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
                        <?php if (isAdmin()): ?>
                            <a href="admin_dashboard.php" class="btn btn--secondary btn--sm">Админ панель</a>
                        <?php else: ?>
                            <a href="client_dashboard.php" class="btn btn--secondary btn--sm">Мой кабинет</a>
                        <?php endif; ?>
                        <a href="logout.php" class="btn btn--outline btn--sm">Выйти</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn--outline btn--sm">Войти</a>
                        <a href="register.php" class="btn btn--primary btn--sm">Регистрация</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <main class="main">
        <section class="hero">
            <div class="container">
                <div class="hero__content">
                    <h1 class="hero__title">Профессиональная фотосъемка в студии "Кадр"</h1>
                    <p class="hero__subtitle">Создаем неповторимые кадры, которые останутся с вами навсегда</p>
                    <?php if (!isLoggedIn()): ?>
                        <a href="register.php" class="btn btn--primary btn--lg">Записаться на съемку</a>
                    <?php else: ?>
                        <a href="book_session.php" class="btn btn--primary btn--lg">Записаться на съемку</a>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <section class="services">
            <div class="container">
                <h2 class="section__title">Наши услуги</h2>
                <div class="services__grid">
                    <?php foreach ($services as $service): ?>
                        <div class="service-card">
                            <div class="service-card__image">
                                <img src="https://images.unsplash.com/photo-1554048612-b6a482b22000?w=400&h=300&fit=crop" alt="<?php echo htmlspecialchars($service['name']); ?>">
                            </div>
                            <div class="service-card__content">
                                <h3 class="service-card__title"><?php echo htmlspecialchars($service['name']); ?></h3>
                                <p class="service-card__description"><?php echo htmlspecialchars($service['description']); ?></p>
                                <div class="service-card__price"><?php echo number_format($service['price'], 0, ',', ' '); ?> ₽</div>
                                <?php if (isLoggedIn()): ?>
                                    <a href="book_session.php?service=<?php echo urlencode($service['name']); ?>" class="btn btn--primary">Записаться</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="about">
            <div class="container">
                <div class="about__content">
                    <h2 class="section__title">О нашей студии</h2>
                    <p class="about__text">
                        Фотостудия "Кадр" - это современное пространство, оборудованное профессиональной техникой 
                        и множеством локаций для любых видов съемок. Наши фотографы имеют многолетний опыт работы 
                        и помогут создать уникальные кадры для любого повода.
                    </p>
                    <div class="features">
                        <div class="feature">
                            <h3>Профессиональное оборудование</h3>
                            <p>Современные камеры, объективы и световое оборудование</p>
                        </div>
                        <div class="feature">
                            <h3>Опытные фотографы</h3>
                            <p>Команда профессионалов с многолетним стажем</p>
                        </div>
                        <div class="feature">
                            <h3>Разнообразные локации</h3>
                            <p>Множество студийных интерьеров на любой вкус</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container">
            <div class="footer__content">
                <div class="footer__section">
                    <h3>Контакты</h3>
                    <p>Телефон: +7 (123) 456-78-90</p>
                    <p>Email: info@kadr-studio.ru</p>
                    <p>Адрес: г. Москва, ул. Фотографов, д. 15</p>
                </div>
                <div class="footer__section">
                    <h3>Режим работы</h3>
                    <p>Понедельник - Пятница: 10:00 - 20:00</p>
                    <p>Суббота - Воскресенье: 11:00 - 19:00</p>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>