<?php
require_once 'config/database.php';
startSession();

if (!isLoggedIn()) {
    redirect('login.php');
}

if (isAdmin()) {
    redirect('admin_dashboard.php');
}

// Получаем заявки текущего пользователя
$stmt = $pdo->prepare("SELECT * FROM bookings WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Обработка отмены заявки
if (isset($_GET['cancel']) && is_numeric($_GET['cancel'])) {
    $booking_id = (int)$_GET['cancel'];
    $stmt = $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ? AND user_id = ?");
    $stmt->execute([$booking_id, $_SESSION['user_id']]);
    redirect('client_dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет - Фотостудия "Кадр"</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header__content">
                <div class="logo">
                    <h1><a href="index.php">Кадр</a></h1>
                    <span>фотостудия</span>
                </div>
                <nav class="nav">
                    <ul class="nav__list">
                        <li><a href="index.php" class="nav__link">Главная</a></li>
                        <li><a href="search.php" class="nav__link">Услуги</a></li>
                        <li><a href="book_session.php" class="nav__link">Записаться</a></li>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <span class="user-name">Привет, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
                    <a href="logout.php" class="btn btn--outline btn--sm">Выйти</a>
                </div>
            </div>
        </div>
    </header>

    <main class="main">
        <section class="dashboard">
            <div class="container">
                <h1 class="dashboard__title">Личный кабинет</h1>

                <div class="dashboard__actions">
                    <a href="book_session.php" class="btn btn--primary">Новая заявка на съемку</a>
                </div>

                <div class="bookings-section">
                    <h2>Мои заявки</h2>

                    <?php if (empty($bookings)): ?>
                        <div class="empty-state">
                            <p>У вас пока нет заявок на фотосессии.</p>
                            <a href="book_session.php" class="btn btn--primary">Записаться на съемку</a>
                        </div>
                    <?php else: ?>
                        <div class="bookings-table">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Услуга</th>
                                        <th>Дата и время</th>
                                        <th>Статус</th>
                                        <th>Сообщение</th>
                                        <th>Создано</th>
                                        <th>Действия</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bookings as $booking): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($booking['service_type']); ?></td>
                                            <td>
                                                <?php 
                                                $date = new DateTime($booking['shoot_date']);
                                                echo $date->format('d.m.Y') . ' в ' . substr($booking['shoot_time'], 0, 5);
                                                ?>
                                            </td>
                                            <td>
                                                <span class="status status--<?php echo $booking['status']; ?>">
                                                    <?php 
                                                    switch($booking['status']) {
                                                        case 'pending': echo 'Ожидает'; break;
                                                        case 'confirmed': echo 'Подтверждена'; break;
                                                        case 'cancelled': echo 'Отменена'; break;
                                                    }
                                                    ?>
                                                </span>
                                            </td>
                                            <td><?php echo htmlspecialchars($booking['message']); ?></td>
                                            <td>
                                                <?php 
                                                $created = new DateTime($booking['created_at']);
                                                echo $created->format('d.m.Y H:i');
                                                ?>
                                            </td>
                                            <td>
                                                <?php if ($booking['status'] === 'pending'): ?>
                                                    <a href="?cancel=<?php echo $booking['id']; ?>" 
                                                       class="btn btn--danger btn--sm"
                                                       onclick="return confirm('Вы уверены, что хотите отменить заявку?')">
                                                        Отменить
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</body>
</html>