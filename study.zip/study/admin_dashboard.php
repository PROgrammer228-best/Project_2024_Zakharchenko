<?php
require_once 'config/database.php';
startSession();

if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

// Обработка действий админа
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['booking_id'])) {
        $booking_id = (int)$_POST['booking_id'];
        $action = $_POST['action'];

        if ($action === 'confirm') {
            $stmt = $pdo->prepare("UPDATE bookings SET status = 'confirmed' WHERE id = ?");
            $stmt->execute([$booking_id]);
        } elseif ($action === 'cancel') {
            $stmt = $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ?");
            $stmt->execute([$booking_id]);
        }
        redirect('admin_dashboard.php');
    }
}

// Получаем статистику
$stats = [];
$stmt = $pdo->query("SELECT COUNT(*) as total FROM bookings");
$stats['total_bookings'] = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) as pending FROM bookings WHERE status = 'pending'");
$stats['pending_bookings'] = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) as confirmed FROM bookings WHERE status = 'confirmed'");
$stats['confirmed_bookings'] = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'client'");
$stats['total_clients'] = $stmt->fetchColumn();

// Получаем все заявки с информацией о пользователях
$stmt = $pdo->query("
    SELECT b.*, u.username, u.email 
    FROM bookings b 
    JOIN users u ON b.user_id = u.id 
    ORDER BY b.created_at DESC
");
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Получаем всех пользователей
$stmt = $pdo->query("SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ панель - Фотостудия "Кадр"</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header__content">
                <div class="logo">
                    <h1><a href="index.php">Кадр</a></h1>
                    <span>фотостудия</span>
                </div>
                <nav class="nav">
                    <ul class="nav__list">
                        <li><a href="index.php" class="nav__link">Главная</a></li>
                        <li><a href="search.php" class="nav__link">Услуги</a></li>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <span class="user-name">Админ: <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <a href="logout.php" class="btn btn--outline btn--sm">Выйти</a>
                </div>
            </div>
        </div>
    </header>

    <main class="main">
        <section class="admin-dashboard">
            <div class="container">
                <h1 class="dashboard__title">Админ панель</h1>

                <!-- Статистика -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <h3>Всего заявок</h3>
                        <div class="stat-number"><?php echo $stats['total_bookings']; ?></div>
                    </div>
                    <div class="stat-card">
                        <h3>Ожидают подтверждения</h3>
                        <div class="stat-number"><?php echo $stats['pending_bookings']; ?></div>
                    </div>
                    <div class="stat-card">
                        <h3>Подтверждено</h3>
                        <div class="stat-number"><?php echo $stats['confirmed_bookings']; ?></div>
                    </div>
                    <div class="stat-card">
                        <h3>Клиентов</h3>
                        <div class="stat-number"><?php echo $stats['total_clients']; ?></div>
                    </div>
                </div>

                <!-- Управление заявками -->
                <div class="admin-section">
                    <h2>Управление заявками</h2>

                    <?php if (empty($bookings)): ?>
                        <p>Пока нет заявок.</p>
                    <?php else: ?>
                        <div class="bookings-table">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Клиент</th>
                                        <th>Email</th>
                                        <th>Услуга</th>
                                        <th>Дата и время</th>
                                        <th>Статус</th>
                                        <th>Сообщение</th>
                                        <th>Создано</th>
                                        <th>Действия</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($bookings as $booking): ?>
                                        <tr>
                                            <td><?php echo $booking['id']; ?></td>
                                            <td><?php echo htmlspecialchars($booking['username']); ?></td>
                                            <td><?php echo htmlspecialchars($booking['email']); ?></td>
                                            <td><?php echo htmlspecialchars($booking['service_type']); ?></td>
                                            <td>
                                                <?php 
                                                $date = new DateTime($booking['shoot_date']);
                                                echo $date->format('d.m.Y') . ' в ' . substr($booking['shoot_time'], 0, 5);
                                                ?>
                                            </td>
                                            <td>
                                                <span class="status status--<?php echo $booking['status']; ?>">
                                                    <?php 
                                                    switch($booking['status']) {
                                                        case 'pending': echo 'Ожидает'; break;
                                                        case 'confirmed': echo 'Подтверждена'; break;
                                                        case 'cancelled': echo 'Отменена'; break;
                                                    }
                                                    ?>
                                                </span>
                                            </td>
                                            <td><?php echo htmlspecialchars($booking['message']); ?></td>
                                            <td>
                                                <?php 
                                                $created = new DateTime($booking['created_at']);
                                                echo $created->format('d.m.Y H:i');
                                                ?>
                                            </td>
                                            <td>
                                                <?php if ($booking['status'] === 'pending'): ?>
                                                    <form method="POST" style="display: inline;">
                                                        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                                        <button type="submit" name="action" value="confirm" class="btn btn--success btn--sm">Подтвердить</button>
                                                        <button type="submit" name="action" value="cancel" class="btn btn--danger btn--sm">Отклонить</button>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Управление пользователями -->
                <div class="admin-section">
                    <h2>Пользователи системы</h2>

                    <div class="users-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Имя пользователя</th>
                                    <th>Email</th>
                                    <th>Роль</th>
                                    <th>Дата регистрации</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo $user['id']; ?></td>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td>
                                            <span class="role role--<?php echo $user['role']; ?>">
                                                <?php echo $user['role'] === 'admin' ? 'Администратор' : 'Клиент'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php 
                                            $created = new DateTime($user['created_at']);
                                            echo $created->format('d.m.Y H:i');
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>
</body>
</html>