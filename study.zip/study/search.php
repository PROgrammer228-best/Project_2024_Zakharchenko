<?php
require_once 'config/database.php';
startSession();

$search_query = '';
$services = [];

if (isset($_GET['search'])) {
    $search_query = trim($_GET['search']);
    if (!empty($search_query)) {
        $stmt = $pdo->prepare("SELECT * FROM services WHERE name LIKE ? OR description LIKE ? ORDER BY name");
        $search_term = '%' . $search_query . '%';
        $stmt->execute([$search_term, $search_term]);
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} else {
    // Если поиск не задан, показываем все услуги
    $stmt = $pdo->query("SELECT * FROM services ORDER BY name");
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Поиск услуг - Фотостудия "Кадр"</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header__content">
                <div class="logo">
                    <h1><a href="index.php">Кадр</a></h1>
                    <span>фотостудия</span>
                </div>
                <nav class="nav">
                    <ul class="nav__list">
                        <li><a href="index.php" class="nav__link">Главная</a></li>
                        <li><a href="search.php" class="nav__link active">Услуги</a></li>
                        <?php if (isLoggedIn()): ?>
                            <li><a href="book_session.php" class="nav__link">Записаться</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <?php if (isLoggedIn()): ?>
                        <span class="user-name">Привет, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
                        <?php if (isAdmin()): ?>
                            <a href="admin_dashboard.php" class="btn btn--secondary btn--sm">Админ панель</a>
                        <?php else: ?>
                            <a href="client_dashboard.php" class="btn btn--secondary btn--sm">Мой кабинет</a>
                        <?php endif; ?>
                        <a href="logout.php" class="btn btn--outline btn--sm">Выйти</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn--outline btn--sm">Войти</a>
                        <a href="register.php" class="btn btn--primary btn--sm">Регистрация</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <main class="main">
        <section class="search-section">
            <div class="container">
                <h1 class="section__title">Наши услуги</h1>

                <!-- Форма поиска -->
                <div class="search-form-container">
                    <form method="GET" class="search-form">
                        <div class="search-input-group">
                            <input type="text" name="search" class="search-input" 
                                   placeholder="Поиск по услугам..." 
                                   value="<?php echo htmlspecialchars($search_query); ?>">
                            <button type="submit" class="btn btn--primary">Найти</button>
                        </div>
                    </form>

                    <?php if (!empty($search_query)): ?>
                        <div class="search-results-info">
                            <p>Результаты поиска для: "<strong><?php echo htmlspecialchars($search_query); ?></strong>"</p>
                            <a href="search.php" class="btn btn--outline btn--sm">Показать все услуги</a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Результаты поиска -->
                <div class="services-results">
                    <?php if (empty($services)): ?>
                        <div class="no-results">
                            <h3>Ничего не найдено</h3>
                            <p>По вашему запросу ничего не найдено. Попробуйте изменить поисковый запрос.</p>
                            <a href="search.php" class="btn btn--primary">Показать все услуги</a>
                        </div>
                    <?php else: ?>
                        <div class="services__grid">
                            <?php 
                            // Массив изображений для разных типов услуг
                            $service_images = [
                                'Портретная' => 'https://images.unsplash.com/photo-1554048612-b6a482b22000?w=400&h=300&fit=crop',
                                'Семейная' => 'https://images.unsplash.com/photo-1511895426328-dc8714191300?w=400&h=300&fit=crop',
                                'Свадебная' => 'https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=400&h=300&fit=crop',
                                'Корпоративная' => 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=300&fit=crop',
                                'Love' => 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=400&h=300&fit=crop',
                                'Детская' => 'https://images.unsplash.com/photo-1544717302-de2939b7ef71?w=400&h=300&fit=crop'
                            ];

                            foreach ($services as $service): 
                                $image_url = 'https://images.unsplash.com/photo-1554048612-b6a482b22000?w=400&h=300&fit=crop';
                                foreach ($service_images as $key => $url) {
                                    if (strpos($service['name'], $key) !== false) {
                                        $image_url = $url;
                                        break;
                                    }
                                }
                            ?>
                                <div class="service-card">
                                    <div class="service-card__image">
                                        <img src="<?php echo $image_url; ?>" alt="<?php echo htmlspecialchars($service['name']); ?>">
                                    </div>
                                    <div class="service-card__content">
                                        <h3 class="service-card__title"><?php echo htmlspecialchars($service['name']); ?></h3>
                                        <p class="service-card__description"><?php echo htmlspecialchars($service['description']); ?></p>
                                        <div class="service-card__price"><?php echo number_format($service['price'], 0, ',', ' '); ?> ₽</div>
                                        <div class="service-card__actions">
                                            <?php if (isLoggedIn()): ?>
                                                <a href="book_session.php?service=<?php echo urlencode($service['name']); ?>" 
                                                   class="btn btn--primary">Записаться</a>
                                            <?php else: ?>
                                                <a href="login.php" class="btn btn--primary">Войти для записи</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="services-count">
                            <p>Найдено услуг: <?php echo count($services); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</body>
</html>