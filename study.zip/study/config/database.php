<?php
// config/database.php
$host = 'localhost';
$dbname = 'photo_studio';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Функция для хеширования паролей
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

// Функция для проверки паролей
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Функция для запуска сессии
function startSession() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
}

// Функция для проверки авторизации
function isLoggedIn() {
    startSession();
    return isset($_SESSION['user_id']);
}

// Функция для проверки роли админа
function isAdmin() {
    startSession();
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

// Функция для редиректа
function redirect($url) {
    header("Location: $url");
    exit();
}
?>