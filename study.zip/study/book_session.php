<?php
require_once 'config/database.php';
startSession();

if (!isLoggedIn()) {
    redirect('login.php');
}

$error = '';
$success = '';

// Получаем доступные услуги
$stmt = $pdo->query("SELECT name FROM services ORDER BY name");
$services = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Предзаполняем услугу если передана через GET
$selected_service = isset($_GET['service']) ? $_GET['service'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service_type = trim($_POST['service_type']);
    $shoot_date = trim($_POST['shoot_date']);
    $shoot_time = trim($_POST['shoot_time']);
    $message = trim($_POST['message']);

    if (empty($service_type) || empty($shoot_date) || empty($shoot_time)) {
        $error = 'Пожалуйста, заполните все обязательные поля';
    } else {
        $booking_date = new DateTime($shoot_date);
        $today = new DateTime();

        if ($booking_date <= $today) {
            $error = 'Дата съемки должна быть в будущем';
        } else {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO bookings (user_id, service_type, shoot_date, shoot_time, message, status) 
                    VALUES (?, ?, ?, ?, ?, 'pending')
                ");
                $stmt->execute([
                    $_SESSION['user_id'],
                    $service_type,
                    $shoot_date,
                    $shoot_time,
                    $message
                ]);

                $success = 'Заявка успешно подана! Мы свяжемся с вами в ближайшее время.';

                // Очищаем форму после успешной отправки
                $_POST = [];
                $selected_service = '';
            } catch (PDOException $e) {
                $error = 'Ошибка при отправке заявки: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Записаться на съемку - Фотостудия "Кадр"</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header__content">
                <div class="logo">
                    <h1><a href="index.php">Кадр</a></h1>
                    <span>фотостудия</span>
                </div>
                <nav class="nav">
                    <ul class="nav__list">
                        <li><a href="index.php" class="nav__link">Главная</a></li>
                        <li><a href="search.php" class="nav__link">Услуги</a></li>
                        <li><a href="book_session.php" class="nav__link active">Записаться</a></li>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <span class="user-name">Привет, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
                    <?php if (isAdmin()): ?>
                        <a href="admin_dashboard.php" class="btn btn--secondary btn--sm">Админ панель</a>
                    <?php else: ?>
                        <a href="client_dashboard.php" class="btn btn--secondary btn--sm">Мой кабинет</a>
                    <?php endif; ?>
                    <a href="logout.php" class="btn btn--outline btn--sm">Выйти</a>
                </div>
            </div>
        </div>
    </header>

    <main class="main">
        <section class="booking-section">
            <div class="container">
                <h1 class="section__title">Записаться на фотосессию</h1>

                <?php if ($error): ?>
                    <div class="alert alert--error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert--success">
                        <?php echo htmlspecialchars($success); ?>
                        <a href="client_dashboard.php">Перейти в личный кабинет</a>
                    </div>
                <?php endif; ?>

                <div class="booking-form-container">
                    <form method="POST" class="booking-form">
                        <div class="form-group">
                            <label for="service_type" class="form-label">Тип фотосессии *</label>
                            <select id="service_type" name="service_type" class="form-select" required>
                                <option value="">Выберите услугу</option>
                                <?php foreach ($services as $service): ?>
                                    <option value="<?php echo htmlspecialchars($service); ?>" 
                                            <?php echo ($selected_service === $service || (isset($_POST['service_type']) && $_POST['service_type'] === $service)) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($service); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="shoot_date" class="form-label">Желаемая дата *</label>
                                <input type="date" id="shoot_date" name="shoot_date" class="form-input" 
                                       value="<?php echo isset($_POST['shoot_date']) ? htmlspecialchars($_POST['shoot_date']) : ''; ?>" 
                                       min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="shoot_time" class="form-label">Желаемое время *</label>
                                <select id="shoot_time" name="shoot_time" class="form-select" required>
                                    <option value="">Выберите время</option>
                                    <?php
                                    $times = ['10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'];
                                    foreach ($times as $time):
                                    ?>
                                        <option value="<?php echo $time; ?>" 
                                                <?php echo (isset($_POST['shoot_time']) && $_POST['shoot_time'] === $time) ? 'selected' : ''; ?>>
                                            <?php echo $time; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="message" class="form-label">Дополнительные пожелания</label>
                            <textarea id="message" name="message" class="form-textarea" rows="5" 
                                      placeholder="Расскажите о ваших пожеланиях, особенностях съемки, количестве людей и т.д."><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                        </div>

                        <button type="submit" class="btn btn--primary btn--full">Отправить заявку</button>
                    </form>

                    <div class="booking-info">
                        <h3>Информация о бронировании</h3>
                        <ul>
                            <li>Заявка будет рассмотрена администратором в течение 24 часов</li>
                            <li>После подтверждения мы свяжемся с вами для уточнения деталей</li>
                            <li>Предоплата составляет 50% от стоимости услуги</li>
                            <li>Отмена возможна не позднее чем за 24 часа до съемки</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    </main>
</body>
</html>