-- setup.sql
-- Создание базы данных для фотостудии
USE cq07724_photo;

-- Таблица пользователей
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('client', 'admin') DEFAULT 'client',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица услуг
CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица бронирований/заявок
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    service_type VARCHAR(100) NOT NULL,
    shoot_date DATE NOT NULL,
    shoot_time TIME NOT NULL,
    status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Вставка тестовых пользователей
INSERT INTO users (username, email, password, role) VALUES 
('admin', 'admin@photostudio.ru', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('client1', 'client1@test.ru', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'client'),
('client2', 'client2@test.ru', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'client');

-- Пароли для тестовых пользователей:
-- admin: admin123
-- client1: client123  
-- client2: client456

-- Вставка услуг
INSERT INTO services (name, description, price) VALUES 
('Портретная съемка', 'Индивидуальная портретная фотосессия в студии', 5000.00),
('Семейная фотосессия', 'Фотосессия для всей семьи в уютной атмосфере', 7000.00),
('Свадебная съемка', 'Полный день свадебной съемки с обработкой фотографий', 25000.00),
('Корпоративная съемка', 'Деловые портреты и фото корпоративных мероприятий', 8000.00),
('Love Story', 'Романтическая фотосессия для пары', 6000.00),
('Детская фотосессия', 'Фотосессия для детей любого возраста', 4500.00);

-- Вставка тестовых заявок
INSERT INTO bookings (user_id, service_type, shoot_date, shoot_time, status, message) VALUES 
(2, 'Портретная съемка', '2025-10-15', '14:00:00', 'pending', 'Хочу сделать профессиональные фото для портфолио. Предпочитаю классический стиль.'),
(3, 'Семейная фотосессия', '2025-10-20', '11:00:00', 'confirmed', 'Фотосессия с детьми 5 и 8 лет. Нужны живые, естественные кадры.'),
(2, 'Love Story', '2025-10-25', '16:00:00', 'pending', 'Романтическая съемка с партнером. Хотели бы получить нежные фотографии.');

-- Создание индексов для лучшей производительности
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_bookings_user_id ON bookings(user_id);
CREATE INDEX idx_bookings_date ON bookings(shoot_date);
CREATE INDEX idx_bookings_status ON bookings(status);