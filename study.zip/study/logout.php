<?php
require_once 'config/database.php';
startSession();

// Уничтожаем сессию
session_destroy();

// Перенаправляем на главную страницу
redirect('index.php');
?>