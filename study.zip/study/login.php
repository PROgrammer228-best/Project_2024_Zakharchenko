<?php
require_once 'config/database.php';
startSession();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $error = 'Пожалуйста, заполните все поля';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id, username, email, password, role FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && verifyPassword($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_role'] = $user['role'];

                if ($user['role'] === 'admin') {
                    redirect('admin_dashboard.php');
                } else {
                    redirect('client_dashboard.php');
                }
            } else {
                $error = 'Неверный email или пароль';
            }
        } catch (PDOException $e) {
            $error = 'Ошибка базы данных: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход - Фотостудия "Кадр"</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header__content">
                <div class="logo">
                    <h1><a href="index.php">Кадр</a></h1>
                    <span>фотостудия</span>
                </div>
                <nav class="nav">
                    <ul class="nav__list">
                        <li><a href="index.php" class="nav__link">Главная</a></li>
                        <li><a href="search.php" class="nav__link">Услуги</a></li>
                    </ul>
                </nav>
                <div class="auth-buttons">
                    <a href="register.php" class="btn btn--primary btn--sm">Регистрация</a>
                </div>
            </div>
        </div>
    </header>

    <main class="main">
        <section class="auth-section">
            <div class="container">
                <div class="auth-form-container">
                    <h1 class="auth-form__title">Вход в личный кабинет</h1>

                    <?php if ($error): ?>
                        <div class="alert alert--error"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <form method="POST" class="auth-form">
                        <div class="form-group">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" id="email" name="email" class="form-input" 
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="password" class="form-label">Пароль</label>
                            <input type="password" id="password" name="password" class="form-input" required>
                        </div>

                        <button type="submit" class="btn btn--primary btn--full">Войти</button>
                    </form>

                    <div class="auth-links">
                        <p>Нет аккаунта? <a href="register.php">Зарегистрируйтесь</a></p>
                    </div>

                    <div class="test-accounts">
                        <h3>Тестовые аккаунты:</h3>
                        <p><strong>Админ:</strong> admin@photostudio.ru / admin123</p>
                        <p><strong>Клиент 1:</strong> client1@test.ru / client123</p>
                        <p><strong>Клиент 2:</strong> client2@test.ru / client456</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
</body>
</html>